create definer = root@localhost view guest_booking as
select `utopia`.`booking`.`id`                  AS `id`,
       `utopia`.`booking`.`is_active`           AS `is_active`,
       `utopia`.`booking`.`confirmation_code`   AS `confirmation_code`,
       `utopia`.`booking_guest`.`contact_email` AS `contact_email`,
       `utopia`.`booking_guest`.`contact_phone` AS `contact_phone`,
       `utopia`.`booking_agent`.`agent_id`      AS `agent_id`
from ((`utopia`.`booking` join `utopia`.`booking_guest` on ((`utopia`.`booking`.`id` = `utopia`.`booking_guest`.`booking_id`)))
         left join `utopia`.`booking_agent` on ((`utopia`.`booking`.`id` = `utopia`.`booking_agent`.`booking_id`)));

