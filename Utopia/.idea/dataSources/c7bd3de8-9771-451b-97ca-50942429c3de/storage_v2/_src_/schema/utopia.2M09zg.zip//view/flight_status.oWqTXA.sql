create definer = root@localhost view flight_status as
select `utopia`.`flight`.`id`                       AS `id`,
       `utopia`.`flight`.`route_id`                 AS `route_id`,
       `utopia`.`flight`.`airplane_id`              AS `airplane_id`,
       `utopia`.`flight`.`departure_time`           AS `departure_time`,
       `utopia`.`flight`.`reserved_seats`           AS `reserved_seats`,
       `utopia`.`flight`.`seat_price`               AS `seat_price`,
       `airplane_capacity`.`max_capacity`           AS `max_capacity`,
       `flight_passenger_count`.`passenger_count`   AS `passenger_count`,
       ((`airplane_capacity`.`max_capacity` - `utopia`.`flight`.`reserved_seats`) -
        `flight_passenger_count`.`passenger_count`) AS `available_seats`
from ((`utopia`.`flight` join (select `utopia`.`airplane`.`id`                AS `id`,
                                      `utopia`.`airplane_type`.`max_capacity` AS `max_capacity`
                               from (`utopia`.`airplane`
                                        join `utopia`.`airplane_type`
                                             on ((`utopia`.`airplane`.`type_id` = `utopia`.`airplane_type`.`id`)))) `airplane_capacity` on ((`utopia`.`flight`.`airplane_id` = `airplane_capacity`.`id`)))
         join (select `utopia`.`flight_passengers`.`flight_id` AS `flight_id`, count(0) AS `passenger_count`
               from `utopia`.`flight_passengers`
               group by `utopia`.`flight_passengers`.`flight_id`) `flight_passenger_count`
              on ((`utopia`.`flight`.`id` = `flight_passenger_count`.`flight_id`)));

