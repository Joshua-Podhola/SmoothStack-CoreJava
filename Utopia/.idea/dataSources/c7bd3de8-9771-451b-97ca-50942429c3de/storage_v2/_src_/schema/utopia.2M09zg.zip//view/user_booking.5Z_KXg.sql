create definer = root@localhost view user_booking as
select `booking`.`id`                AS `id`,
       `booking`.`is_active`         AS `is_active`,
       `booking`.`confirmation_code` AS `confirmation_code`,
       `booking_user`.`user_id`      AS `user_id`,
       `booking_agent`.`agent_id`    AS `agent_id`
from ((`booking` join `booking_user` on ((`booking`.`id` = `booking_user`.`booking_id`)))
         left join `booking_agent` on ((`booking`.`id` = `booking_agent`.`booking_id`)));

