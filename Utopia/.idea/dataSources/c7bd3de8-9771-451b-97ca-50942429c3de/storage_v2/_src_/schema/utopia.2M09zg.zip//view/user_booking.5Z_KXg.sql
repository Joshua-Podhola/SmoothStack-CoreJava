create definer = root@localhost view user_booking as
select `utopia`.`booking`.`id`                AS `id`,
       `utopia`.`booking`.`is_active`         AS `is_active`,
       `utopia`.`booking`.`confirmation_code` AS `confirmation_code`,
       `utopia`.`booking_user`.`user_id`      AS `user_id`,
       `utopia`.`booking_agent`.`agent_id`    AS `agent_id`
from ((`utopia`.`booking` join `utopia`.`booking_user` on ((`utopia`.`booking`.`id` = `utopia`.`booking_user`.`booking_id`)))
         left join `utopia`.`booking_agent` on ((`utopia`.`booking`.`id` = `utopia`.`booking_agent`.`booking_id`)));

