create definer = root@localhost view flight_passengers as
select `flight_bookings`.`flight_id`  AS `flight_id`,
       `flight_bookings`.`booking_id` AS `booking_id`,
       `passenger`.`id`               AS `passenger_id`
from ((`flight_bookings` join `passenger` on ((`flight_bookings`.`booking_id` = `passenger`.`booking_id`)))
         join `booking` on ((`flight_bookings`.`booking_id` = `booking`.`id`)))
where (`booking`.`is_active` = true);

