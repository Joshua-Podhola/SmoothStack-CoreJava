create definer = root@localhost view guest_booking as
select `booking`.`id`                  AS `id`,
       `booking`.`is_active`           AS `is_active`,
       `booking`.`confirmation_code`   AS `confirmation_code`,
       `booking_guest`.`contact_email` AS `contact_email`,
       `booking_guest`.`contact_phone` AS `contact_phone`,
       `booking_agent`.`agent_id`      AS `agent_id`
from ((`booking` join `booking_guest` on ((`booking`.`id` = `booking_guest`.`booking_id`)))
         left join `booking_agent` on ((`booking`.`id` = `booking_agent`.`booking_id`)));

