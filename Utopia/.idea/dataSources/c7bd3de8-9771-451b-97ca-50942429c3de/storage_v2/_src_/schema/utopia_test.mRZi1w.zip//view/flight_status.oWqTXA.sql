create definer = root@localhost view flight_status as
select `flight`.`id`                                AS `id`,
       `flight`.`route_id`                          AS `route_id`,
       `flight`.`airplane_id`                       AS `airplane_id`,
       `flight`.`departure_time`                    AS `departure_time`,
       `flight`.`reserved_seats`                    AS `reserved_seats`,
       `flight`.`seat_price`                        AS `seat_price`,
       `airplane_capacity`.`max_capacity`           AS `max_capacity`,
       `flight_passenger_count`.`passenger_count`   AS `passenger_count`,
       ((`airplane_capacity`.`max_capacity` - `flight`.`reserved_seats`) -
        `flight_passenger_count`.`passenger_count`) AS `available_seats`
from ((`flight` join (select `airplane`.`id` AS `id`, `airplane_type`.`max_capacity` AS `max_capacity`
                      from (`airplane`
                               join `airplane_type` on ((`airplane`.`type_id` = `airplane_type`.`id`)))) `airplane_capacity` on ((`flight`.`airplane_id` = `airplane_capacity`.`id`)))
         join (select `flight_passengers`.`flight_id` AS `flight_id`, count(0) AS `passenger_count`
               from `flight_passengers`
               group by `flight_passengers`.`flight_id`) `flight_passenger_count`
              on ((`flight`.`id` = `flight_passenger_count`.`flight_id`)));

